package com.example.terms_tik_tok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Terms_Activity extends AppCompatActivity {

    public static final String CODE = "sialoquent";
    public TextView termsView;
    public EditText editText;
    public Button agree;
    public Button disagree;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_);

        editText = findViewById( R.id.editText2 );
        createAgree();
        createDisagree();

        termsView = findViewById( R.id.textView3 );
    }

    public void createAgree() {
        agree = findViewById( R.id.button3 );
        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra( MainActivity.ACCEPTED_BOOLEAN, true );
                intent.putExtra(MainActivity.ENTERED_CODE, editText.getText().toString() );
                setResult( 1, intent );
                finish();
            }
        });
    }

    public void createDisagree() {
        disagree = findViewById( R.id.button4 );
        disagree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra( MainActivity.ACCEPTED_BOOLEAN, false );
                intent.putExtra(MainActivity.ENTERED_CODE, editText.getText().toString() );
                setResult( 1, intent );
                finish();
            }
        });
    }
}
